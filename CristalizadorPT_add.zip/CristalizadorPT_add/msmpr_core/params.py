"""Parámetros base del MSMPR de KNO3 con su procedencia.

Regla del proyecto (ver AGENTS.md): ningún valor se inventa en silencio. Cada clave de BASE
tiene una etiqueta en PROVENANCE:

  'respaldado'  : valor con fuente (Perry, IAPWS, Rolfs, Selzer...). Ver parametros/parametros_DPBE.csv
  'interno'     : dato de SQM/GEA o de tus balances, sin confirmar con la planta
  'placeholder' : valor ilustrativo; hay que calibrarlo o ajustarlo con datos

Unidades: SI. Concentraciones en kg/m3 de pulpa (~licor), temperaturas en degC en la interfaz.
"""
from __future__ import annotations

import math
from copy import deepcopy

M_KNO3 = 0.1011032          # kg/mol
M_H2O = 0.0180153           # kg/mol
KCAL = 4184.0               # J/kcal
R_GAS = 8.314462618         # J/(mol K)

BASE = {
    # --- Geometría y flujos (interno: hojas GEA / balance de masa; actualizar con datos de planta)
    "volume_m3": 660.0,
    "feed_flow_m3_s": 280.83 / 3600.0,       # caudal total de alimentación (stock + agua de dilución)
    "feed_dilution_fraction": 0.05,          # d = Q_dil / Q_total
    "crystallizer_temperature_C": 40.0,
    "feed_temperature_C": 55.0,
    "dilution_water_temperature_C": 20.0,    # agua de proceso (P&ID: process water 20 degC)
    "tank_volume_m3": 150.0,                 # tanque de licor madre (B3520); placeholder
    # --- Alimentación
    "feed_stock_kg_m3": {"KNO3": 220.0,      # placeholder (ver nota: SSK-d da ~525 kg/m3 a 70 degC)
                         "ClO4": 5.56379},   # interno: informe §2, base iónica SSK-d (antes 3.8e-3: base distinta)
    # --- Termodinámica
    "reference_temperature_C": 40.0,
    "Cstar_ref_kg_m3": 180.0,                # placeholder: solubilidad en salmuera NO medida
    "solubility_slope_K_inv": 0.0312,        # Perry Tabla 2-122 (pendiente de q, agua pura, 30-50 degC)
    "deltaH_crystallization_J_kg": 7.73 * KCAL / M_KNO3,   # interno: -7.73 kcal/mol (319.9 kJ/kg)
    "latent_heat_J_kg": 2.406081e6,          # respaldado: IAPWS SR1, agua pura a 40 degC
    "solution_cp_J_kg_K": 2178.0,            # interno/estimado (alternativa: 2248, corriente 334)
    "rho_liquid_kg_m3": 1470.0,              # interno: PFD GEA
    "rho_water_kg_m3": 998.2,                # respaldado: IAPWS SR6 a 20 degC
    "cp_water_J_kg_K": 4184.19,              # respaldado: IAPWS SR6 a 20 degC
    "water_mass_fraction_liquor": 0.3994,    # interno: corriente 334 SSK-d
    # --- Cristal
    "rho_crystal_kg_m3": 2110.0,             # respaldado: Perry Tabla 2-1
    "kv": math.pi / 6.0,                     # exacto por definición (diámetro de esfera equivalente)
    # --- Cinética (placeholders: calibrar con datos; Rolfs/Selzer no son directamente transferibles)
    "kG_m_s": 2.0e-7,
    "g": 1.0,
    "Eg_J_mol": 0.0,                         # energía de activación del crecimiento (sin dato)
    "kB_m3_s_inv": 1.0e10,
    "b": 2.0,
    # --- Impureza ClO4 (placeholders; el informe dice: no hay Kd validado)
    "Kd": 0.002,                             # w_cristal / w_licor
    "cake_moisture_fraction": 0.03,
    "centrifuge_wash_eff": 0.75,
    # --- Recirculación
    "purge_fraction_alpha": 0.25,            # fracción del licor madre que se purga
    # --- Calidad (interno, provisional)
    "spec_ClO4_ppm_max": 40.0,
}

PROVENANCE = {k: "placeholder" for k in BASE}
PROVENANCE.update({
    "volume_m3": "interno", "feed_flow_m3_s": "interno", "feed_temperature_C": "interno",
    "crystallizer_temperature_C": "interno", "tank_volume_m3": "placeholder",
    "dilution_water_temperature_C": "interno",
    "feed_stock_kg_m3": "placeholder (KNO3) / interno (ClO4)",
    "solubility_slope_K_inv": "respaldado", "deltaH_crystallization_J_kg": "interno",
    "latent_heat_J_kg": "respaldado", "solution_cp_J_kg_K": "interno",
    "rho_liquid_kg_m3": "interno", "rho_water_kg_m3": "respaldado", "cp_water_J_kg_K": "respaldado",
    "water_mass_fraction_liquor": "interno", "rho_crystal_kg_m3": "respaldado", "kv": "respaldado",
    "spec_ClO4_ppm_max": "interno",
})


# ---------------------------------------------------------------------------------------------
# Perfil 'calibracion': la base EXACTA del notebook MSMPR_KNO3_DPBE_sensibilidad_Pareto.ipynb, que es el modelo
# que usa calibracion_do_crystal.ipynb. Los kG, kB y Kd que se calibren allí solo valen sobre ESTA base
# (solubilidad, densidades, factor de forma): al cambiarla hay que recalibrar.
# ---------------------------------------------------------------------------------------------
BASE_CALIBRACION = {
    "volume_m3": 660.0,
    "feed_dilution_fraction": 0.05,
    "crystallizer_temperature_C": 40.0,
    "residence_time": 660.0 / (280.83 / 3600.0),          # s; en este notebook Q se deriva de V/tau
    "feed_stock_kg_m3": {"KNO3": 220.0, "ClO4": 3.799262673e-3},
    "reference_temperature_C": 40.0,
    "Cstar_ref_kg_m3": 180.0,
    "solubility_slope_K_inv": 0.010,
    "kG_m_s": 2.0e-7, "g": 1.0, "kB_m3_s_inv": 1.0e10, "b": 2.0,
    "rho_crystal_kg_m3": 2100.0, "kv": math.pi / 6.0,
    "Kd": 0.01, "rho_liquid_kg_m3": 1040.0,
}
# claves que condicionan los parámetros calibrados (si difieren, kG/kB/Kd no son transferibles)
BASIS_KEYS = ["reference_temperature_C", "Cstar_ref_kg_m3", "solubility_slope_K_inv",
              "rho_crystal_kg_m3", "kv", "rho_liquid_kg_m3"]
CALIBRATED_KEYS = ["kG_m_s", "kB_m3_s_inv", "Kd", "g", "b"]


def _deep_update(p: dict, src: dict) -> None:
    for k, v in src.items():
        if isinstance(v, dict) and isinstance(p.get(k), dict):
            p[k].update(v)
        else:
            p[k] = deepcopy(v)


def make_params(profile: str = "literatura", **overrides) -> dict:
    """Copia de BASE con sobrescrituras (admite 'feed_stock_kg_m3' parcial: {'KNO3': 525.0}).

    profile='literatura'  : valores respaldados con fuente donde existen (Perry, IAPWS...). Por defecto.
    profile='calibracion' : base del notebook de Pareto/calibración (ver BASE_CALIBRACION). Con ella, el
                            término de humedad de torta se anula porque su Kd ya absorbe todo el ClO4 del producto seco.
    """
    if profile not in ("literatura", "calibracion"):
        raise ValueError("profile debe ser 'literatura' o 'calibracion'")
    p = deepcopy(BASE)
    p["profile"] = profile
    if profile == "calibracion":
        src = {k: v for k, v in BASE_CALIBRACION.items() if k != "residence_time"}
        _deep_update(p, src)
        p["feed_flow_m3_s"] = BASE_CALIBRACION["volume_m3"] / BASE_CALIBRACION["residence_time"]
        p["cake_moisture_fraction"] = 0.0
    for k, v in overrides.items():
        if k not in p:
            raise KeyError(f"Parámetro desconocido: {k}")
        if isinstance(p[k], dict) and isinstance(v, dict):
            p[k].update(v)
        else:
            p[k] = v
    return p


def diff_bases():
    """Tabla de diferencias entre el perfil 'literatura' y el de 'calibracion' (lo que hay que alinear)."""
    import pandas as pd
    a, b = make_params("literatura"), make_params("calibracion")
    rows = []
    for k in list(BASE_CALIBRACION) + ["cake_moisture_fraction"]:
        if k == "residence_time":
            continue
        va, vb = a[k], b[k]
        if isinstance(va, dict):
            for kk in va:
                if va[kk] != vb[kk]:
                    rows.append({"parametro": f"{k}.{kk}", "literatura": va[kk], "calibracion": vb[kk],
                                 "condiciona_calibracion": False})
        elif va != vb:
            rows.append({"parametro": k, "literatura": va, "calibracion": vb,
                         "condiciona_calibracion": k in BASIS_KEYS})
    return pd.DataFrame(rows)


def load_base_from_notebook(path: str) -> dict:
    """Extrae BASE del notebook de Pareto (sin ejecutarlo) para comprobar que BASE_CALIBRACION no se desfasó."""
    import ast
    import json
    nb = json.load(open(path, encoding="utf-8"))
    for c in nb["cells"]:
        if c["cell_type"] != "code":
            continue
        src = "".join(c["source"])
        for node in ast.parse(src).body:
            if isinstance(node, ast.Assign) and any(getattr(t, "id", "") == "BASE" for t in node.targets):
                return eval(compile(ast.Expression(node.value), "BASE", "eval"), {"math": math})
    raise ValueError("No se encontró BASE en el notebook")


def apply_calibration(p: dict, calibration, equipment: str = "", force: bool = False) -> dict:
    """Inserta kG, kB, Kd (y g, b si vienen) calibrados en `p`, comprobando que la base coincide.

    calibration: dict {'kG_m_s':..., 'kB_m3_s_inv':..., 'Kd':...}  o  DataFrame con columnas
    'parameter' y 'optimized' (la tabla que imprime calibracion_do_crystal.ipynb).
    Si alguna clave de BASIS_KEYS de `p` difiere de la base con que se calibró, lanza ValueError (force=True la ignora).
    """
    if hasattr(calibration, "columns"):
        calibration = dict(zip(calibration["parameter"], calibration["optimized"].astype(float)))
    bad = [k for k in BASIS_KEYS if p[k] != BASE_CALIBRACION[k]]
    if bad and not force:
        raise ValueError(f"La base difiere de la de calibración en {bad}: kG/kB/Kd no son transferibles. "
                         "Usa make_params('calibracion') o recalibra.")
    q = deepcopy(p)
    for k, v in calibration.items():
        if k not in CALIBRATED_KEYS:
            raise KeyError(f"Solo se aceptan {CALIBRATED_KEYS}; llegó {k}")
        q[k] = float(v)
    q["cake_moisture_fraction"] = 0.0          # el Kd calibrado ya incluye el arrastre de licor
    q["calibrated_for"] = equipment or "sin especificar"
    return q


def placeholders(p: dict | None = None) -> list[str]:
    """Claves cuyo valor sigue siendo un supuesto: lo que hay que calibrar antes de sacar conclusiones."""
    return [k for k, v in PROVENANCE.items() if v.startswith("placeholder")]


def literature_table(csv_path: str):
    """Lee parametros/parametros_DPBE.csv (informe de parámetros) como DataFrame para consulta."""
    import pandas as pd
    return pd.read_csv(csv_path, encoding="utf-8-sig")
